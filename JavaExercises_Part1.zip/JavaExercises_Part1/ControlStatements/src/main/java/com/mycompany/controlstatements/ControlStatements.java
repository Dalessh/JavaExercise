/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.controlstatements;

import java.util.Scanner;

/**
 *
 * @author tanki
 */
public class ControlStatements {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;
    

do {
            System.out.println("\nSelect an operation:");
            System.out.println("1.check if number is odd or even ");
            System.out.println("2.Find the largest of three numbers ");
            System.out.println("3.Check if a year is a leap year ");
            System.out.println("4.calculator program");
            System.out.println("5.Check if a character is a vowel or consonant ");
            System.out.println("6. Exit");
            System.out.print("Enter your choice (1-6): ");

            choice = scanner.nextInt();
switch(choice){
    case 1:
        OddEven(scanner);
        break;
        case 2:
            LargestNumber(scanner);
        break;
      
        case 3: 
       LeapYear(scanner);
       break;
        case 4:
            Calculator(scanner);
            break;
        case 5:
            VowelConsonant(scanner);
            break;
        case 6:
            System.out.println("Exiting the program. GOOOOOBYE");
            break;
        default:
            System.out.println("Invalid input. Select from 1-6");
            break;
}
    }while (choice != 6);
  scanner.close();
}
    public static void OddEven(Scanner scanner){
        System.out.println("Enter number");
        int num = scanner.nextInt();
        if(num %2==0){
             System.out.println("The  number  is Even");  
        }else{
               System.out.println("The  number is Odd");
        }
    }
    public static void LargestNumber(Scanner scanner){
        int num1,num2, num3;
         System.out.println("Enter the first number ");
         num1 = scanner.nextInt();
          System.out.println("Enter the second  number ");
         num2 = scanner.nextInt();
         
          System.out.println("Enter the third number ");
         num3 = scanner.nextInt();
         
         if(num1 >num2 && num1 >num3){
              System.out.println("Num1 is the largest ");
         
         }else if(num2>num1 && num2 > num3){
          System.out.println("num2 is the largest ");
         }else{
              System.out.println("Num3 is the largest ");
         }
    }
    public static void LeapYear(Scanner scanner){
         System.out.println("Enter a year ");
         int year = scanner.nextInt();
         if((year % 400 == 0) || (year % 4 == 0 && year % 100 != 0)){
             System.out.println("Year is a leap year ");
         }else{
             System.out.println("Year is not a LeapYear ");
         }
    }
     public static void Calculator(Scanner scanner){
            System.out.print("Enter first number: ");
        double a = scanner.nextDouble();
        System.out.print("Enter second number: ");
        double b = scanner.nextDouble();
        System.out.print("Choose operation (+ - * /): ");
        char op = scanner.next().charAt(0);

        switch (op) {
            case '+': System.out.println("Result: " + (a + b));
            break;
            case '-': System.out.println("Result: " + (a - b));
            break;
            case '*': System.out.println("Result: " + (a * b));
            break;
            case '/': System.out.println("Result: " + (a / b));
            break;
            default: System.out.println("Invalid operator");
        }
     }
     public static void VowelConsonant(Scanner scanner){
           System.out.print("Enter a character: ");
        char ch = scanner.next().toLowerCase().charAt(0);

        if ("aeiou".indexOf(ch) != -1){
            System.out.println(ch + " is a Vowel");
        } else{
            System.out.println(ch + " is a Consonant");
     }
        }
    }

