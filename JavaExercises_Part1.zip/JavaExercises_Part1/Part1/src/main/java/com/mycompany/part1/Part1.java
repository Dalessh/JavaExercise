/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.part1;
import java.util.Scanner;
/**
 *
 * @author tanki
 */
public class Part1 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\nSelect an operation:");
            System.out.println("1. Print 'Hello, World!'");
            System.out.println("2. Swap two numbers without a temporary variable");
            System.out.println("3. Convert Celsius to Fahrenheit");
            System.out.println("4. Find the largest of three numbers");
            System.out.println("5. Print ASCII value of a character");
            System.out.println("6. Exit");
            System.out.print("Enter your choice (1-6): ");

            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    printHelloWorld();
                    break;
                case 2:
                    swapNumbers(scanner);
                    break;
                case 3:
                    convertCelsiusToFahrenheit(scanner);
                    break;
                case 4:
                    findLargestOfThree(scanner);
                    break;
                case 5:
                    printAsciiValue(scanner);
                    break;
                case 6:
                    System.out.println("Exiting the program. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please select between 1 and 6.");
            }
        } while (choice != 6);

        scanner.close();
    }

    public static void printHelloWorld() {
        System.out.println("Hello, World!");
    }

    public static void swapNumbers(Scanner scanner) {
        System.out.print("Enter first number: ");
        int a = scanner.nextInt();
        System.out.print("Enter second number: ");
        int b = scanner.nextInt();
        System.out.println("Before swap: a = " + a + ", b = " + b);
        a = a + b;
        b = a - b;
        a = a - b;
        System.out.println("After swap: a = " + a + ", b = " + b);
    }

    public static void convertCelsiusToFahrenheit(Scanner scanner) {
        System.out.print("Enter temperature in Celsius: ");
        double celsius = scanner.nextDouble();
        double fahrenheit = (celsius * 9/5) + 32;
        System.out.println("Fahrenheit: " + fahrenheit);
    }

    public static void findLargestOfThree(Scanner scanner) {
        System.out.print("Enter first number: ");
        int num1 = scanner.nextInt();
        System.out.print("Enter second number: ");
        int num2 = scanner.nextInt();
        System.out.print("Enter third number: ");
        int num3 = scanner.nextInt();

        int largest = num1;
        if (num2 > largest) {
            largest = num2;
        }
        if (num3 > largest) {
            largest = num3;
        }
        System.out.println("The largest number is: " + largest);
    }

    public static void printAsciiValue(Scanner scanner) {
        System.out.print("Enter a character: ");
        char ch = scanner.next().charAt(0);
        int ascii = (int) ch;
        System.out.println("ASCII value of '" + ch + "' is: " + ascii);
    }
}
