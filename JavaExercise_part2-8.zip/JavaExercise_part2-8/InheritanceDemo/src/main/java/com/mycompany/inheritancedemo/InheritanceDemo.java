/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.inheritancedemo;
import java.util.Scanner;

public class InheritanceDemo {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("=== Inheritance & Polymorphism Practice ===");
        System.out.println("Choose an exercise:");
        System.out.println("1. Single Inheritance");
        System.out.println("2. Hierarchical Inheritance");
        System.out.println("3. Abstract Class Demo");
        System.out.println("4. Multiple Inheritance with Interfaces");
        System.out.println("5. Dynamic Method Dispatch");
        
        System.out.print("Enter your choice (1-5): ");
        int choice = scanner.nextInt();
        
        switch(choice) {
            case 1: singleInheritanceDemo(scanner); break;
            case 2: hierarchicalInheritanceDemo(scanner); break;
            case 3: abstractClassDemo(scanner); break;
            case 4: multipleInheritanceDemo(scanner); break;
            case 5: dynamicMethodDispatchDemo(scanner); break;
            default: System.out.println("Invalid choice!");
        }
        
        scanner.close();
    }
    
    // 1. Single Inheritance Demo
    public static void singleInheritanceDemo(Scanner scanner) {
        System.out.println("=== Single Inheritance ===");
        System.out.println("Creating a Dog object (child of Animal)...");
        
        Dog myDog = new Dog();
        myDog.eat();    // Inherited from Animal
        myDog.bark();   // Dog's own method
        myDog.sleep();  // Inherited from Animal
    }
    
    // 2. Hierarchical Inheritance Demo
    public static void hierarchicalInheritanceDemo(Scanner scanner) {
        System.out.println("=== Hierarchical Inheritance ===");
        System.out.println("Creating Cat and Dog objects (both children of Animal)...");
        
        Cat myCat = new Cat();
        Dog myDog = new Dog();
        
        System.out.println("\n--- Cat ---");
        myCat.eat();
        myCat.meow();
        
        System.out.println("\n--- Dog ---");
        myDog.eat();
        myDog.bark();
    }
    
    // 3. Abstract Class Demo
    public static void abstractClassDemo(Scanner scanner) {
        System.out.println("=== Abstract Class Demo ===");
        System.out.println("Creating Circle and Rectangle objects...");
        
        Circle circle = new Circle(5);
        Rectangle rectangle = new Rectangle(4, 6);
        
        System.out.println("Circle area: " + circle.calculateArea());
        System.out.println("Rectangle area: " + rectangle.calculateArea());
        
        circle.display();    // Inherited from Shape
        rectangle.display(); // Inherited from Shape
    }
    
    // 4. Multiple Inheritance with Interfaces
    public static void multipleInheritanceDemo(Scanner scanner) {
        System.out.println("=== Multiple Inheritance with Interfaces ===");
        System.out.println("Creating a SmartPhone object...");
        
        SmartPhone myPhone = new SmartPhone();
        myPhone.makeCall();
        myPhone.sendMessage();
        myPhone.takePhoto();
        myPhone.browseInternet();
    }
    
    // 5. Dynamic Method Dispatch
    public static void dynamicMethodDispatchDemo(Scanner scanner) {
        System.out.println("=== Dynamic Method Dispatch ===");
        System.out.println("Using parent reference for child objects...");
        
        // Parent reference, child objects
        Animal animal1 = new Dog();
        Animal animal2 = new Cat();
        Animal animal3 = new Animal();
        
        System.out.println("\nCalling makeSound() with different objects:");
        System.out.print("Animal reference to Dog: ");
        animal1.makeSound();
        
        System.out.print("Animal reference to Cat: ");
        animal2.makeSound();
        
        System.out.print("Animal reference to Animal: ");
        animal3.makeSound();
    }
}

// 1. Single Inheritance Classes
class Animal {
    void eat() {
        System.out.println("Animal is eating...");
    }
    
    void sleep() {
        System.out.println("Animal is sleeping...");
    }
    
    void makeSound() {
        System.out.println("Animal makes a sound");
    }
}

class Dog extends Animal {
    void bark() {
        System.out.println("Dog is barking: Woof woof!");
    }
    
    @Override
    void makeSound() {
        System.out.println("Dog says: Woof woof!");
    }
}

// 2. Hierarchical Inheritance Classes
class Cat extends Animal {
    void meow() {
        System.out.println("Cat is meowing: Meow meow!");
    }
    
    @Override
    void makeSound() {
        System.out.println("Cat says: Meow meow!");
    }
}

// 3. Abstract Class and Methods
abstract class Shape {
    // Abstract method (must be implemented by subclasses)
    abstract double calculateArea();
    
    // Concrete method
    void display() {
        System.out.println("This is a shape");
    }
}

class Circle extends Shape {
    double radius;
    
    public Circle(double radius) {
        this.radius = radius;
    }
    
    @Override
    double calculateArea() {
        return 3.14 * radius * radius;
    }
}

class Rectangle extends Shape {
    double width;
    double height;
    
    public Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }
    
    @Override
    double calculateArea() {
        return width * height;
    }
}

// 4. Multiple Inheritance using Interfaces
interface Phone {
    void makeCall();
    void sendMessage();
}

interface Camera {
    void takePhoto();
}

interface Internet {
    void browseInternet();
}

class SmartPhone implements Phone, Camera, Internet {
    @Override
    public void makeCall() {
        System.out.println("Making a phone call...");
    }
    
    @Override
    public void sendMessage() {
        System.out.println("Sending a text message...");
    }
    
    @Override
    public void takePhoto() {
        System.out.println("Taking a photo with camera...");
    }
    
    @Override
    public void browseInternet() {
        System.out.println("Browsing the internet...");
    }
}



    

