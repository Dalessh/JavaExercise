/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.methods;
import java.util.Scanner;
/**
 *
 * @author tanki
 */
public class Methods {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;
       do{
        System.out.println("1. Check Prime Number");
        System.out.println("2. Factorial");
        System.out.println("3. Greatest Common Divisor (GCD)");
        System.out.println("4. Reverse String");
        System.out.println("5. Check Palindrome Number");
         System.out.println("6. Exit");
        System.out.print("Enter your choice (1-6): ");
         choice = scanner.nextInt();
         switch(choice){
           case 1: 
               checkPrime(scanner);
           break;
            case 2: 
                factorial(scanner); 
                break;
            case 3: 
                findGCD(scanner);
                break;
            case 4: 
                reverseString(scanner);
                break;
            case 5: 
                checkNumberPalindrome(scanner);
                break; 
            case 6:
                    System.out.println("Exiting the program. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please select between 1 and 6.");
            }
        } while (choice != 6);
       scanner.close();
    }
    
    public static void checkPrime(Scanner scanner) {
        System.out.print("Enter a number: ");
        int num = scanner.nextInt();
        
        if(num <= 1) {
            System.out.println(num + " is NOT prime.");
            return;
        }
        
        boolean isPrime = true;
        for(int i = 2; i <= Math.sqrt(num); i++) {
            if(num % i == 0) {
                isPrime = false;
                break;
            }
        }
        
        if(isPrime) {
            System.out.println(num + " is prime!");
        } else {
            System.out.println(num + " is NOT prime.");
        }
    }
    
     public static void factorial(Scanner scanner) {
        System.out.print("Enter a number: ");
        int num = scanner.nextInt();
        
        long result = 1;
        for(int i = 1; i <= num; i++) {
            result *= i;
        }
        
        System.out.println("Factorial of " + num + " is: " + result);
    }
     
      public static void findGCD(Scanner scanner) {
        System.out.print("Enter first number: ");
        int a = scanner.nextInt();
        System.out.print("Enter second number: ");
        int b = scanner.nextInt();
        
        while(b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        
        System.out.println("GCD is: " + a);
    }
      
       public static void reverseString(Scanner scanner) {
        System.out.print("Enter a string: ");
        String str = scanner.next();
        
        String reversed = "";
        for(int i = str.length()-1; i >= 0; i--) {
            reversed += str.charAt(i);
        }
        
        System.out.println("Reversed string: " + reversed);
    }
       
       public static void checkNumberPalindrome(Scanner scanner) {
        System.out.print("Enter a number: ");
        int num = scanner.nextInt();
        int original = num;
        
        int reversed = 0;
        while(num != 0) {
            reversed = reversed * 10 + num % 10;
            num /= 10;
        }
        
        if(original == reversed) {
            System.out.println(original + " is a palindrome number!");
        } else {
            System.out.println(original + " is NOT a palindrome number.");
        }
    }
}
