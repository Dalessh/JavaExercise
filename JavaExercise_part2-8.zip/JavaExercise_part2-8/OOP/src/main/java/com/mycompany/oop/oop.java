/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.oop;
import java.util.Scanner;
/**
 *
 * @author tanki
 */
public class oop {

    public static void main(String[] args) {
        int choice;
        Scanner scanner = new Scanner(System.in);
       do{
        System.out.println("1. Car Class Demo");
        System.out.println("2. Bank Account Demo");
        System.out.println("3. Inheritance Demo");
        System.out.println("4. Exit");
        System.out.print("Enter your choice (1-3): ");
        
              choice = scanner.nextInt();
         switch(choice){
          case 1:
              carDemo(scanner);
              break;
            case 2: 
                bankAccountDemo(scanner);
                break;
            case 3: 
                inheritanceDemo(scanner);
                break; 
            case 4:
                    System.out.println("Exiting the program. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please select between 1 and 3.");
            }
        } while (choice != 3);
       scanner.close();
    }
    
      public static void carDemo(Scanner scanner) {
        System.out.print("Enter car make: ");
        String make = scanner.next();
        System.out.print("Enter car model: ");
        String model = scanner.next();
        System.out.print("Enter car year: ");
        int year = scanner.nextInt();
        
        Car myCar = new Car(make, model, year);
        myCar.displayInfo();
        myCar.startEngine();
        myCar.stopEngine();
    }
    
        public static void bankAccountDemo(Scanner scanner) {
        BankAccount account = new BankAccount(1000);
        
        System.out.print("Enter deposit amount: ");
        double deposit = scanner.nextDouble();
        account.deposit(deposit);
        
        System.out.print("Enter withdrawal amount: ");
        double withdraw = scanner.nextDouble();
        account.withdraw(withdraw);
        
        account.checkBalance();
    }
    
        public static void inheritanceDemo(Scanner scanner) {
        System.out.println("=== Shape Demo ===");
        Circle circle = new Circle(5);
        Rectangle rectangle = new Rectangle(4, 6);
        
        System.out.println("Circle area: " + circle.area());
        System.out.println("Rectangle area: " + rectangle.area());
        
        System.out.println("\n=== Animal Demo ===");
        Animal animal = new Animal();
        Dog dog = new Dog();
        
        animal.makeSound();
        dog.makeSound();
    }
}
    
    class Car {
    String make;
    String model;
    int year;
    
    public Car(String make, String model, int year) {
        this.make = make;
        this.model = model;
        this.year = year;
    }
    
    void displayInfo() {
        System.out.println(year + " " + make + " " + model);
    }
    
    void startEngine() {
        System.out.println("Engine started! Vroom vroom!");
    }
    
    void stopEngine() {
        System.out.println("Engine stopped.");
    }
}
    
    class BankAccount {
    double balance;
    
        public BankAccount(double initialBalance) {
        this.balance = initialBalance;
    }
    
    void deposit(double amount) {
        balance += amount;
        System.out.println("Deposited: $" + amount);
    }
    
    void withdraw(double amount) {
        if(amount <= balance) {
            balance -= amount;
            System.out.println("Withdrew: $" + amount);
        } else {
            System.out.println("Insufficient funds!");
        }
    }
    
    void checkBalance() {
        System.out.println("Current balance: $" + balance);
    }
}
    
    class Shape {
    double area() {
        return 0;
    }
}
    class Circle extends Shape {
    double radius;
    
    public Circle(double radius) {
        this.radius = radius;
    }
    
    @Override
    double area() {
        return 3.14 * radius * radius;
    }
}
class Rectangle extends Shape {
    double width;
    double height;
    
    public Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }

    
       }
    
class Animal {
    void makeSound() {
        System.out.println("Animal makes a sound");
    }
}
class Dog extends Animal {
    @Override
    void makeSound() {
        System.out.println("Dog says: Woof woof!");
    }
}
