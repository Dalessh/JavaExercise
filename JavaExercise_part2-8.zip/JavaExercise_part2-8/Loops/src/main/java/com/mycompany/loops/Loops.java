/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.loops;

import java.util.Scanner;

/**
 *
 * @author tanki
 */
public class Loops {

    public static void main(String[] args) {
         Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\nSelect an operation:");
            System.out.println("1.Find the factorial of a number ");
            System.out.println("2.Generate the Fibonacci series up to n terms");
            System.out.println("3.Reverse a given number ");
            System.out.println("4.Find the sum of digits of a number ");
            System.out.println("5.Print all prime numbers between 1 and 100");
            System.out.println("6. Exit");
            System.out.print("Enter your choice (1-6): ");

            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    Factorial(scanner);
                    break;
                case 2:
                    FibonacciSeries (scanner);
                    break;
                case 3:
                    ReverseNumber(scanner);
                    break;
                case 4:
                    Sum(scanner);
                    break;
                case 5:
                    PrimeNumbers(scanner);
                    break;
                case 6:
                    System.out.println("Exiting the program. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please select between 1 and 6.");
            }
        } while (choice != 6);

        scanner.close();
    }
    public static void Factorial(Scanner scanner) {
       System.out.print("Enter number: ");
        int n = scanner.nextInt();
        long fact = 1;
        for (int i = 1; i <= n; i++) fact *= i;
        System.out.println("Factorial: " + fact);
    }

    public static void FibonacciSeries(Scanner scanner) {
       int n, term1,term2,next;
        term1 = 0;
        term2 =1;
         System.out.print("Enter the number to be printed in the fiboncci series");
         n=scanner.nextInt();
        System.out.print(term1+"");
         for(int i=0; i<n;i++){
          System.out.print("fibonacci:");
          next = term1 + term2;
          term1 = term2;
          term2=next;
         }
    }

    public static void ReverseNumber(Scanner scanner) {
           int num = scanner.nextInt(), rev = 0;
        while (num != 0) {
            rev = rev * 10 + num % 10;
            num /= 10;
        }
        System.out.println("Reversed: " + rev);
    }

    public static void Sum(Scanner scanner) {
      int num = scanner.nextInt(), sum = 0;
        while (num != 0) {
            sum += num % 10;
            num /= 10;
        }
        System.out.println("Sum: " + sum);
    }

    public static void PrimeNumbers(Scanner scanner) {
        System.out.println("Prime numbers 1–100:");
        for (int i = 2; i <= 100; i++) {
            boolean prime = true;
            for (int j = 2; j <= Math.sqrt(i); j++) {
                if (i % j == 0) {
                    prime = false;
                
                break; 
                }
            }
            if (prime) System.out.print(i + " ");
        }
    }
}
