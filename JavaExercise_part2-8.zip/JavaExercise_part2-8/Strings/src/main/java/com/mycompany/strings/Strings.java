/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.strings;
import java.util.HashMap;
import java.util.Scanner;

/**
 *
 * @author tanki
 */

public class Strings {

    public static void main(String[] args) {
         Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\nSelect an operation:");
            System.out.println("1.Check if a string is a palindrome");
            System.out.println("2.Count the number of vowels in a string");
            System.out.println("3.Find the frequency of characters in a string ");
            System.out.println("4.Check if two strings are anagrams");
            System.out.println("5.Find the longest word in a sentence");
            System.out.println("6. Exit");
            System.out.print("Enter your choice (1-6): ");

            choice = scanner.nextInt();

            switch (choice) {
                case 1: 
                    checkPalindrome(scanner);
                    break;
            case 2: 
                    countVowels(scanner); 
                    break;
            case 3: 
                    characterFrequency(scanner);
                    break;
            case 4: 
                    checkAnagram(scanner);
                    break;
            case 5:
                    findLongestWord(scanner);
                    break;
             case 6:
                    System.out.println("Exiting the program. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please select between 1 and 6.");
            }
        } while (choice != 6);

        scanner.close();
    }
   public static void checkPalindrome(Scanner scanner) {
        System.out.print("Enter a string: ");
        String str = scanner.next();
        
        String reversed = "";
        for(int i = str.length()-1; i >= 0; i--) {
            reversed += str.charAt(i);
        }
        
        if(str.equals(reversed)) {
            System.out.println(str + " is a palindrome!");
        } else {
            System.out.println(str + " is NOT a palindrome.");
        }
    }
public static void countVowels(Scanner scanner) {
        System.out.print("Enter a string: ");
        String str = scanner.next().toLowerCase();
        
        int vowelCount = 0;
        for(int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            if(c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
                vowelCount++;
            }
        }
        
        System.out.println("Number of vowels: " + vowelCount);
    }

     public static void characterFrequency(Scanner scanner) {
        System.out.print("Enter a string: ");
        String str = scanner.next();
        
        HashMap<Character, Integer> frequency = new HashMap<>();
        
        for(int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            if(frequency.containsKey(c)) {
                frequency.put(c, frequency.get(c) + 1);
            } else {
                frequency.put(c, 1);
            }
        }
        
        System.out.println("Character frequencies:");
        for(char c : frequency.keySet()) {
            System.out.println(c + ": " + frequency.get(c));
        }
    }
     
        public static void checkAnagram(Scanner scanner) {
        System.out.print("Enter first string: ");
        String str1 = scanner.next();
        System.out.print("Enter second string: ");
        String str2 = scanner.next();
        
        if(str1.length() != str2.length()) {
            System.out.println("Not anagrams - different lengths!");
            return;
        }
        
        int[] count1 = new int[256];
        int[] count2 = new int[256];
        
        for(int i = 0; i < str1.length(); i++) {
            count1[str1.charAt(i)]++;
            count2[str2.charAt(i)]++;
        }
        
        boolean isAnagram = true;
        for(int i = 0; i < 256; i++) {
            if(count1[i] != count2[i]) {
                isAnagram = false;
                break;
            }
        }
        }
   public static void findLongestWord(Scanner scanner) {
        System.out.print("Enter a sentence: ");
        scanner.nextLine(); // Clear buffer
        String sentence = scanner.nextLine();
        
        String[] words = sentence.split(" ");
        String longestWord = "";
        
        for(String word : words) {
            if(word.length() > longestWord.length()) {
                longestWord = word;
            }
        }
        
        System.out.println("Longest word: " + longestWord);
        System.out.println("Length: " + longestWord.length() + " characters");
    }
}